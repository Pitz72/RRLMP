export type MidiMessageCallback = (note: number, velocity: number, command: number) => void;


class MidiManager {
    private static instance: MidiManager;
    private listeners: MidiMessageCallback[] = [];
    private access: any = null;

    private constructor() {
        // @ts-ignore
        if (navigator.requestMIDIAccess) {
            this.init();
        } else {
            console.warn("MIDI API not supported in this environment.");
        }
    }

    public static getInstance(): MidiManager {
        if (!MidiManager.instance) {
            MidiManager.instance = new MidiManager();
        }
        return MidiManager.instance;
    }

    private async init() {
        try {
            // @ts-ignore
            this.access = await navigator.requestMIDIAccess();
            if (this.access) {
                // Listen to existing inputs
                this.access.inputs.forEach((input: any) => {
                    input.onmidimessage = this.handleMidiMessage.bind(this);
                });

                // Listen for new connections
                this.access.onstatechange = (e: any) => {
                    if (e.port.type === 'input' && e.port.state === 'connected') {
                        e.port.onmidimessage = this.handleMidiMessage.bind(this);
                    }
                };
                console.log("MIDI System Initialized. Inputs found:", this.access.inputs.size);
            }
        } catch (err) {
            console.error("MIDI Init Failed:", err);
        }
    }

    private handleMidiMessage(event: any) {

        const [command, note, velocity] = event.data;

        // Command 144 (0x90) is Note On.
        // Some devices send Note On with 0 velocity as Note Off. We filter those.
        if ((command === 144 && velocity > 0) || command === 176) {
            this.listeners.forEach(fn => fn(note, velocity, command));
        }

    }

    public addListener(callback: MidiMessageCallback) {
        this.listeners.push(callback);
        return () => {
            this.listeners = this.listeners.filter(l => l !== callback);
        };
    }
}

export default MidiManager;
