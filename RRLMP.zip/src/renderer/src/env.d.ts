/// <reference types="vite/client" />

declare const __APP_VERSION__: string;

interface Window {
    electron: {
        ipcRenderer: {
            send: (channel: string, ...args: any[]) => void;
            on: (channel: string, func: (...args: any[]) => void) => void;
            invoke: (channel: string, ...args: any[]) => Promise<any>;
        };
        saveProject: (data: string) => Promise<{ success: boolean; filePath?: string; error?: string }>;
        saveProjectDirect: (data: string, filePath: string) => Promise<{ success: boolean; filePath?: string; error?: string }>;
        saveProjectSilent: (data: string, filePath?: string) => Promise<{ success: boolean; path?: string; error?: string }>;
        loadProject: () => Promise<{ success: boolean; data?: string; filePath?: string; error?: string }>;
        exportProject: (data: string) => Promise<{ success: boolean; path?: string; stats?: { copied: number; skipped: number }; error?: string }>;
        onExportProgress: (callback: (e: any, data: { current: number; total: number; filename: string }) => void) => () => void;
    };
}
