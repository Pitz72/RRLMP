export const toFileUrl = (filePath: string): string => {
    // 1. Normalize slashes (Windows backslash -> Forward slash)
    const normalized = filePath.replace(/\\/g, '/');

    // 2. Native File Access (requires webSecurity: false in Main)
    // We use file:/// protocol to let Chromium handle reading, buffering and decoding.
    // This solves DEMUXER_ERROR and other fragility issues of custom streams.
    return `file:///${normalized}`;
};
